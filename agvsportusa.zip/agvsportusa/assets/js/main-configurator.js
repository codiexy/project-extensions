(function ($) {
  console.clear();
  console.log('svgColor');

  var cursors = document.querySelectorAll('.custom-cursor');
  var mainHolder, colorHolder;
  var currentColorBox = document.querySelector('.current-color-box');
  var currentColorName = document.querySelector('.current-color-name');
  var colorsContainer = document.querySelector('.colors-container');
  var currentColor = document.querySelector('.current-color');
  var btnRandom, btnClear, btnDownloadSVG, btnDownloadPNG;
  var svgObject, svgOutline, svgColor, front, back, allBackShapes;
  var swatchUp, swatchDown;
  var svgSaveName = 'CustomSuit';
  var fillSpeed = 0.15;
  var chosenColorClass = '';
  let colorCount = 0;
  var undoElement = $('#btnUnDo');
  var prevElement = $('#btnPrev');
  var selectedColors = [];
  var uniqueColors = [];

  var newColors = [
    {
      name: 'Classic Black',
      color: '#000001',
      dark: true,
      slug: 'classic-black',
      shade: 'M',
    },
    {
      name: 'Shiny Black',
      color: '#24231C',
      dark: true,
      slug: 'shiny-black',
      shade: '',
    },
    {
      name: 'Gun Metal Grey',
      color: '#2C3538',
      dark: true,
      slug: 'gun-metal-grey',
      shade: 'P',
    },
    {
      name: 'Light Grey',
      color: '#97AAB7',
      dark: false,
      slug: 'light-grey',
      shade: '',
    },
    {
      name: 'Pearlescent White',
      color: '#FBFCF5',
      dark: false,
      slug: 'pearlescent-white',
      shade: 'P',
    },
    {
      name: 'White',
      color: '#ffffff',
      dark: false,
      slug: 'white',
      shade: '',
    },
    {
      name: 'Flou Yellow',
      color: '#D6FF00',
      dark: false,
      slug: 'flou-yellow',
      shade: '',
    },
    {
      name: 'Sunshine Yellow',
      color: '#FCFF15',
      dark: false,
      slug: 'sunshine-yellow',
      shade: '',
    },
    {
      name: 'Golden Yellow',
      color: '#FFDE00',
      dark: false,
      slug: 'golden-yellow',
      shade: '',
    },
    {
      name: 'Flou Orange',
      color: '#FD3700',
      dark: true,
      slug: 'flou-orange',
      shade: '',
    },
    {
      name: 'Matte Flou Orange',
      color: '#FD3700',
      dark: true,
      slug: 'matte-flou-orange',
      shade: 'M',
    },
    {
      name: 'Hermes Orange',
      color: '#FC541A',
      dark: true,
      slug: 'hermes-orange',
      shade: '',
    },
    {
      name: 'Flou Pink',
      color: '#F82950',
      dark: true,
      slug: 'flou-pink',
      shade: '',
    },
    {
      name: 'Hot Pink',
      color: '#EA1174',
      dark: true,
      slug: 'hot-pink',
      shade: '',
    },
    {
      name: 'Flou Red',
      color: '#E02A00',
      dark: true,
      slug: 'flou-red',
      shade: '',
    },
    {
      name: 'Race Red',
      color: '#D61616',
      dark: true,
      slug: 'race-red',
      shade: '',
    },
    {
      name: 'Purple Haze',
      color: '#5A1081',
      dark: true,
      slug: 'purple-haze',
      shade: '',
    },
    {
      name: 'Tiffany Blue',
      color: '#32C7F3',
      dark: false,
      slug: 'tiffany-blue',
      shade: '',
    },
    {
      name: 'Pale Blue',
      color: '#5CA8D6',
      dark: true,
      slug: 'pale-blue',
      shade: '',
    },
    {
      name: 'Light Blue',
      color: '#1E8FE2',
      dark: true,
      slug: 'light-blue',
      shade: '',
    },
    {
      name: 'Green 320C',
      color: '#108799',
      dark: true,
      slug: 'green-320c',
      shade: '',
    },
    {
      name: 'Blue 300C',
      color: '#0F51B2',
      dark: true,
      slug: 'blue-300c',
      shade: '',
    },
    {
      name: 'Pearl Blue',
      color: '#043A75',
      dark: true,
      slug: 'pearl-blue',
      shade: 'P',
    },
    {
      name: 'Royal Blue',
      color: '#22289E',
      dark: true,
      slug: 'royal-blue',
      shade: '',
    },
    {
      name: 'Dunlop Blue',
      color: '#051C7A',
      dark: true,
      slug: 'dunlop-blue',
      shade: '',
    },
    {
      name: 'Flou Green',
      color: '#8DFF43',
      dark: false,
      slug: 'flou-green',
      shade: '',
    },
    {
      name: 'Grass Green',
      color: '#8DE937',
      dark: false,
      slug: 'grass-green',
      shade: '',
    },
    {
      name: 'Kawasaki Green',
      color: '#24D13D',
      dark: false,
      slug: 'kawasaki-green',
      shade: '',
    },
    {
      name: 'Green 342C',
      color: '#375027',
      dark: true,
      slug: 'green-342c',
      shade: '',
    },
    {
      name: 'Metallic Gold',
      color: '#DDD352',
      dark: false,
      slug: 'metallic-gold',
      shade: 'P',
    },
    {
      name: 'Metallic Bronze',
      color: '#C4B00B',
      dark: false,
      slug: 'metallic-bronze',
      shade: 'P',
    },
    {
      name: 'Metallic Silver',
      color: '#B5B5B5',
      dark: false,
      slug: 'metallic-silver',
      shade: 'P',
    },
  ];

  var chosenColor = newColors[0].color;
  var chosenColorName = newColors[0].name;

  var closeOffset;

  const staticPanels = [
    'Perf1',
    'Perf2',
    'Perf3',
    'Perf4',
    'Perf5',
    'Perf6',
    'Perf7',
    'Perf8',
    'Perf9',
    'Perf10',
    'Perf11',
    'Perf12',
    'Perf13',
    'Perf14',
    'Perf15',
    'Perf16',
    'Perf17',
    'Perf18',
    'Perf19',
    'Perf20',
    'FSLChest1',
    'FSLChest2',
    'FSLChest3',
    'FSLChest4',
    'FSRChest1',
    'FSRChest2',
    'FSRChest3',
    'FSRChest4',
    'FSLArm1',
    'FSLArm2',
    'FSRArm1',
    'FSRArm2',
    'FSRLeg1',
    'FSRLeg2',
    'FSLLeg1',
    'FSLLeg2',
    'BPRArm1',
    'BPRArm2',
    'BPRLeg1',
    'BPRLeg2',
    'BPRChest',
    'BPLChest',
    'BPLLeg1',
    'BPLLeg2',
    'BPLArm2',
    'BPLArm1',
    'BPNeck',
    'FChestClosureLogo',
    'FLArmLogo',
    'FLapelLogo',
    'FChestLogo',
    'FLShoulderLogo',
    'FRShoulderLogo',
    'FRThighLogo',
    'FLThighLogo',
    'FShinyPucks',
    'FLegGradiant',
    'BLegGradiant',
    'BShinyPucks',
    'BLLegLogo',
    'BRLegLogo',
    'BRShoulderLogo',
    'BLShoulderLogo',
    'BAccordianLogo',
    'BHumpLogo',
    'BAccordians',
    'BBackStitching',
    'BThighStretch',
    'BButtStitching',
    'FRWristHole',
    'FLWristHole',
    'FStitching',
    'FStitching1',
    'FStitching2',
    'FStitching3',
    'FStitching4',
    'FLArmStretch',
    'FRArmStretch',
    'FRWristClosure',
    'FLWristClosure',
    'FLKneeVelcro',
    'FRKneeVelcro',
    'FLKneeLogo',
    'FRKneeLogo',
    'FLWristInner',
    'FRWristInner',
    'FLWristCuff',
    'FRWristCuff',
    'BLCuff',
    'BRCuff',
    'FInsideCollar',
    'BRCalfStretch',
    'BLCalfStretch',
    'BNeckAccordian',
    'FLLegStretch',
    'FRLegStretch',
    'FRLegStretchTop',
    'FLLegStretchTop',
    'BAccordiansSitTop',
    'BRAccordiansTop',
    'BLAccordiansTop',
    'BLAccordiansShoTop',
    'BRAccordiansShoTop',
    'BRAccordiansTorsTop',
    'BLAccordiansTorsTop',
  ];

  const staticPanelsLinkedToDynamicPanels = new Map([
    ['Perf1', 'FLUpperShoulder'],
    ['Perf3', 'FLBicep'],
    ['Perf4', 'FRBicep'],
    ['Perf5', 'FRUpperShoulder'],
    ['Perf6', 'FRPec'],
    ['Perf7', 'FLCenterThigh'],
    ['Perf8', 'FRCenterThigh'],
    ['Perf9', 'FLThorax'],
    ['Perf10', 'FRThorax'],
    ['Perf11', 'FLArmpit'],
    ['Perf12', 'FRAbdomen'],
    ['Perf13', 'FLAbdomen'],
    ['Perf14', 'FRArmpit'],
    ['Perf15', 'FLPec'],
    ['Perf16', 'BHumpTop'],
    ['Perf17', 'BRTricep'],
    ['Perf18', 'BLTricep'],
    ['Perf19', 'BRLats'],
    ['Perf20', 'BLLats'],
    ['FSLChest1', 'FLChest1'],
    ['FSLChest2', 'FLChest2'],
    ['FSLChest3', 'FLChest3'],
    ['FSLChest4', 'FLChest4'],
    ['FSRChest1', 'FRChest1'],
    ['FSRChest2', 'FRChest2'],
    ['FSRChest3', 'FRChest3'],
    ['FSRChest4', 'FRChest4'],
    ['FSRArm1', 'FRArm1'],
    ['FSRArm2', 'FRArm2'],
    ['FSLArm1', 'FLArm1'],
    ['FSLArm2', 'FLArm2'],
    ['FSRLeg1', 'FRLeg1'],
    ['FSRLeg2', 'FRLeg2'],
    ['FSLLeg1', 'FLLeg1'],
    ['FSLLeg2', 'FLLeg2'],
    ['BPRArm1', 'BRArm1'],
    ['BPRArm2', 'BRArm2'],
    ['BPRLeg1', 'BRLeg1'],
    ['BPRLeg2', 'BRLeg2'],
    ['BPRChest', 'BRChest'],
    ['BPLChest', 'BLChest'],
    ['BPLLeg1', 'BLLeg1'],
    ['BPLLeg2', 'BLLeg2'],
    ['BPLArm2', 'BLArm2'],
    ['BPLArm1', 'BLArm1'],
    ['BPNeck', 'BNeck'],
    ['FRLegStretchTop', 'FRLegStretchC'],
    ['FLLegStretchTop', 'FLLegStretchC'],
    ['BAccordiansSitTop', 'BAccordiansSitC'],
    ['BRAccordiansTop', 'BRAccordiansC'],
    ['BLAccordiansTop', 'BLAccordiansC'],
    ['BRAccordiansShoTop', 'BRAccordiansShoC'],
    ['BLAccordiansShoTop', 'BLAccordiansShoC'],
    ['BRAccordiansTorsTop', 'BRAccordiansTorsC'],
    ['BLAccordiansTorsTop', 'BLAccordiansTorsC'],
    ['BSeat', 'BTailbone'],
  ]);

  const dynamicLinkedPanelsOneToMany = new Map([
    // ['BSeat', ['BTailbone']],
    // ['BTailbone', ['BSeat']],
    ['FRWristToElbow', ['BRInnerArm', 'BRInnerElbowToStretch']],
    ['BRInnerArm', ['FRWristToElbow', 'BRInnerElbowToStretch']],
    ['BRInnerElbowToStretch', ['FRWristToElbow', 'BRInnerArm']],
    ['FLWristToElbow', ['BLInnerArm', 'BLInnerElbowToStretch']],
    ['BLInnerArm', ['FLWristToElbow', 'BLInnerElbowToStretch']],
    ['BLInnerElbowToStretch', ['FLWristToElbow', 'BLInnerArm']],
    ['FLElbow', ['BLOuterArm']],
    ['BLOuterArm', ['FLElbow']],
    ['FRElbow', ['BROuterArm']],
    ['BROuterArm', ['FRElbow']],
    ['FRBicep', ['BRTricep']], //Perf4  = FRBicep
    ['BRTricep', ['FRBicep']], //Perf17 = BRTricep
    ['FLBicep', ['BLTricep']], //Perf3  = FLBicep
    ['BLTricep', ['FLBicep']], //Perf18 = BLTricep
    ['FRBicepToLowerShoulder', ['BRAboveTricep']],
    ['BRAboveTricep', ['FRBicepToLowerShoulder']],
    ['FLBicepToLowerShoulder', ['BLAboveTricep']],
    ['BLAboveTricep', ['FLBicepToLowerShoulder']],
    ['FRCollar', ['BRCollar']],
    ['BRCollar', ['FRCollar']],
    ['FLCollar', ['BLCollar']],
    ['BLCollar', ['FLCollar']],
    ['FLLowerShoulder', ['BLLowerShoulder']],
    ['BLLowerShoulder', ['FLLowerShoulder']],
    ['FRLowerShoulder', ['BRLowerShoulder']],
    ['BRLowerShoulder', ['FRLowerShoulder']],
    ['BLOuterElbowToStretch', ['FLElbowToStretch']],
    ['BROuterElbowToStretch', ['FRElbowToStretch']],
    ['FLElbowToStretch', ['BLOuterElbowToStretch']],
    ['FRElbowToStretch', ['BROuterElbowToStretch']],
  ]);
  //Backleg and tailbone should all be the same color
  const frontAndBackLinkedPanels = new Map();
  const svgIdRegex = /(\w+)(_\d*_)/;

  var suitChanges = [];
  var suitPrevChanges = [];

  function updateTooltipsPositions() {
    tooltips = document.querySelectorAll('.colors-container .tooltip');
    containerRect = colorsContainer.getBoundingClientRect();

    tooltips.forEach(function (tooltip) {
      var rect = tooltip.getBoundingClientRect();
      if (rect.left < containerRect.left) {
        tooltip.classList.add('move-right');
      }
      if (rect.right > containerRect.right) {
        tooltip.classList.add('move-left');
      }
    });
  }

  function updateSelectedColors(panel, color) {
    var index = selectedColors.findIndex(function (x) {
      return x.panel.id == panel.id;
    });

    if (index !== -1) {
      selectedColors[index].color = color;
    } else {
      selectedColors.push({ panel: panel, color: color });
    }

    generateSVGColors();
  }

  function generateSVGColors() {
    const suit = document.getElementById('Suit');
    const svgns = 'http://www.w3.org/2000/svg';

    if (!document.getElementById('svg-title')) {
      let svgTitle = document.createElementNS(svgns, 'text');
      let text = document.createTextNode('Selected colors');
      svgTitle.appendChild(text);
      svgTitle.setAttribute('id', 'svg-title');
      svgTitle.setAttribute('x', 150);
      svgTitle.setAttribute('y', 2300);
      svgTitle.setAttribute(
        'style',
        'font-family: "Dosis"; font-weight: 500; font-size: 60px; line-height: 1.2em;'
      );
      suit.appendChild(svgTitle);
    }

    uniqueColors = [];
    document.querySelectorAll('.selected-colors').forEach(function (item) {
      item.remove();
    });

    if (!selectedColors.length) return;

    selectedColors.forEach(function (item) {
      var colorIsNotAdded = uniqueColors.findIndex(function (color) {
        return color.color == item.color;
      });
      if (colorIsNotAdded != -1) return;

      var index = newColors.findIndex(function (color) {
        return color.color == item.color;
      });

      uniqueColors.push({
        name: newColors[index].name,
        color: newColors[index].color,
      });

      document
        .querySelector('[data-color="' + newColors[index].color + '"]')
        .classList.add('selected');
    });

    var positions = {
      rect: {
        x: 150,
        y: 2350,
      },
      name: {
        x: 224,
        y: 2390,
      },
    };

    uniqueColors.forEach(function (color, index) {
      let svgRect = document.createElementNS(svgns, 'rect');
      svgRect.setAttribute('class', 'selected-colors');
      svgRect.setAttribute('x', positions.rect.x);
      svgRect.setAttribute('y', positions.rect.y);
      svgRect.setAttribute('width', 48);
      svgRect.setAttribute('height', 48);
      svgRect.setAttribute('fill', color.color);
      suit.appendChild(svgRect);

      let svgName = document.createElementNS(svgns, 'text');
      let text = document.createTextNode(color.name);
      svgName.appendChild(text);
      svgName.setAttribute('class', 'selected-colors');
      svgName.setAttribute('x', positions.name.x);
      svgName.setAttribute('y', positions.name.y);
      svgName.setAttribute(
        'style',
        'font-family: "Open Sans"; font-weight: 400; font-size: 40px; line-height: 1em;'
      );
      suit.appendChild(svgName);

      if (index == 5) {
        positions.rect.x = 150;
        positions.rect.y = 2430;
        positions.name.x = 224;
        positions.name.y = 2470;
      } else {
        positions.rect.x += 465;
        positions.name.x += 465;
      }
    });
  }

  function simplifySVGId(svgID) {
    var matches = svgIdRegex.exec(svgID);
    if (matches) {
      return matches[1]; //[0] is original string, [1] is the capture-group we care about
    } else {
      return svgID;
    }
  }

  function getSuitParentFromPanel(panel) {
    var suitFound = false;
    var maxSearchDistance = 4;
    var searchCount = 1;
    var searchElement = panel;
    while (!suitFound && searchCount <= maxSearchDistance) {
      if (simplifySVGId(searchElement.id) === 'Suit') {
        suitFound = true;
      } else {
        searchCount++;
        searchElement = searchElement.parentElement;
      }
    }
    return searchElement;
  }

  function updateCursor(slug) {
    var link =
      "url('" +
      document.location.origin +
      '/wp-content/themes/agv-sport/img/cursor/cursor-' +
      slug +
      ".svg'), auto";

    cursors.forEach(function (cursor) {
      cursor.style.cursor = link;
    });

    document.querySelector('.holder').style.display = 'none';
    document.querySelector('.holder').style.display = 'flex';
  }

  updateCursor(newColors[0].slug);

  function swatchClick() {
    //function limit 7 colors in array
    if (colorCount <= 7) {
      colorCount++;
      chosenColor = $(this).data('color');
      chosenColorName = $(this).data('colorName');

      colorHolder[0].innerText = chosenColorName;
      currentColorBox.style.backgroundColor = chosenColor;
      currentColorName.textContent = chosenColorName;
      TweenMax.to(colorHolder, fillSpeed, {
        backgroundColor: chosenColor,
      });

      var slug = $(this).data('slug');
      updateCursor(slug);
    }

    $('.color-item').each(function (index, item) {
      item.classList.remove('current');
    });
    $(this).addClass('current');
    generateSVGColors();
  }

  function swatchMove(e) {
    var moveTo = e.type == 'mouseenter' ? swatchUp : swatchDown;
    if (e.type == 'mouseleave') {
      TweenMax.to(colorHolder, fillSpeed, { backgroundColor: chosenColor });
      colorHolder[0].innerText = chosenColorName;
      chosenColorClass
        ? $(colorHolder[0]).addClass('dark-font')
        : $(colorHolder[0]).removeClass('dark-font');
    }
    TweenMax.to('.swatchHolder', 0.5, moveTo);
  }

  function colorMe() {
    colorPanel(this, chosenColor);
  }

  function svgClear() {
    if (selectedColors.length) {
      selectedColors.forEach(function (change) {
        TweenMax.to(change.panel, fillSpeed, { fill: '#fff' });
      });

      suitChanges = [];
      selectedColors = [];
      suitPrevChanges = [];
      document.querySelectorAll('li.selected').forEach(function (item) {
        item.classList.remove('selected');
      });

      undoElement.removeClass('active');
      prevElement.removeClass('active');

      colorCount = 0;
    }

    selectedColors = [];
    uniqueColors = [];
    generateSVGColors();
  }

  function colorPanel(panel, color) {
    suit = getSuitParentFromPanel(panel);
    simplifiedSVGID = simplifySVGId(panel.id);
    if (staticPanels.includes(simplifiedSVGID)) {
      //if panel is static, e.g., perforations or stretch
      if (staticPanelsLinkedToDynamicPanels.has(simplifiedSVGID)) {
        //if panel is static, but has links
        linkedPanelName =
          staticPanelsLinkedToDynamicPanels.get(simplifiedSVGID); //find static panel's linked panel
        if (dynamicLinkedPanelsOneToMany.has(linkedPanelName)) {
          //if static panel's linked panel has links
          linkedPanel = suit.getElementById(linkedPanelName);
          colorDynamicLinkedPanelOneToMany(linkedPanel, color);
        } else {
          //the static panel only has one linked panel
          colorStaticLinkedPanel(panel, color);
        }
      } else {
        //Panel is static but has NO links
        console.log('Dont Color SVGID: ' + panel.id);
      }
    } else if (dynamicLinkedPanelsOneToMany.has(simplifiedSVGID)) {
      //Panel has linked panels to update as well
      colorDynamicLinkedPanelOneToMany(panel, color);
    } else {
      colorSimplePanel(panel, color);
    }
  }

  function colorSimplePanel(panel, color) {
    TweenMax.to(panel, fillSpeed, { fill: color });
    console.log('Coloring SVGID: ' + panel.id);
    panel.setAttribute('panelName', panel.id);
    suitChanges.push([panel, color]);
    updateSelectedColors(panel, color);
    suitPrevChanges = [];
    undoElement.addClass('active');
    prevElement.removeClass('active');
  }

  function colorStaticLinkedPanel(panel, color) {
    suit = getSuitParentFromPanel(panel);
    linkedPanelName = staticPanelsLinkedToDynamicPanels.get(
      simplifySVGId(panel.id)
    );
    linkedPanel = suit.getElementById(linkedPanelName);
    console.log('Dont Color SVGID: ' + panel.id);
    console.log('Coloring SVGID:' + linkedPanelName + ' instead');
    TweenMax.to(linkedPanel, fillSpeed, { fill: color });
    linkedPanel.setAttribute('panelName', linkedPanelName);
    suitChanges.push([linkedPanel, color]);
    updateSelectedColors(linkedPanel, color);
    suitPrevChanges = [];
    undoElement.addClass('active');
    prevElement.removeClass('active');
  }

  function colorDynamicLinkedPanelOneToMany(panel, color) {
    suit = getSuitParentFromPanel(panel);
    linkedPanels = dynamicLinkedPanelsOneToMany.get(simplifySVGId(panel.id));
    console.log('Coloring SVGID: ' + panel.id);
    TweenMax.to(panel, fillSpeed, { fill: color });
    linkedPanels.forEach(function (panelName) {
      console.log('-----');
      console.log(linkedPanels);
      console.log(panelName);
      console.log('-----');
      linkedPanel = suit.getElementById(panelName);
      console.log('Also coloring linked panel SVGID: ' + panelName);
      TweenMax.to(linkedPanel, fillSpeed, { fill: color });
      linkedPanel.setAttribute('panelName', linkedPanel);
      suitChanges.push([linkedPanel, color]);
      updateSelectedColors(linkedPanel, color);
    });

    suitPrevChanges = [];
    undoElement.addClass('active');
    prevElement.removeClass('active');
  }

  function svgDownloadSVG() {
    var svgInfo = $('<div>')
      .append($(svgObject).clone())
      .html()
      .replace(/\n\t/g, '')
      .replace(/#/g, '%23');
    //  var svgInfo = $("#result-design").html($(svgObject).clone()).html().replace(/\n\t/g, "").replace(/#/g, "%23");
    $(this).attr({
      href: 'data:image/svg+xml;utf8,' + svgInfo,
      download: svgSaveName + '.svg',
      target: '_blank',
    });
  }

  function openForm() {
    window.open(
      'https://form.jotform.com/80515291884159',
      'blank',
      'scrollbars=yes, toolbar=no, width=700, height=800'
    );
    // svgDownloadSVG()
  }

  function undoColoring() {
    if (selectedColors.length > 0) {
      var lastElementIndex = selectedColors.length - 1;
      var lasElement = selectedColors[lastElementIndex];

      TweenMax.to(lasElement.panel, fillSpeed, { fill: '#fff' });
      suitPrevChanges.push(lasElement);
      selectedColors.splice(lastElementIndex);

      if (selectedColors.length < 1) {
        undoElement.removeClass('active');
      }
      prevElement.addClass('active');

      generateSVGColors();

      var isColor = uniqueColors.find(function (color) {
        return color.color == lasElement.color;
      });
      if (!isColor) {
        document
          .querySelector('[data-color="' + lasElement.color + '"]')
          .classList.remove('selected');
      }
    } else {
      return null;
    }
  }

  function prevColoring() {
    var lastElementInChanges = suitPrevChanges.length - 1;
    var getLastPanel = suitPrevChanges[lastElementInChanges];
    TweenMax.to(getLastPanel.panel, fillSpeed, { fill: getLastPanel.color });
    suitPrevChanges.splice(lastElementInChanges);
    selectedColors.push(getLastPanel);

    if (!suitPrevChanges.length) prevElement.removeClass('active');
    undoElement.addClass('active');

    generateSVGColors();
  }

  $.fn.makeSwatches = function () {
    var swatchHolder = $('<ol/>', { class: 'swatchHolder' }).appendTo(this);
    colorHolder = $('<div/>', { class: 'colorHolder', text: 'Current Color' })
      .css('background-color', chosenColor)
      .appendTo(currentColor);
    currentColorBox.style.backgroundColor = chosenColor;
    currentColorName.textContent = chosenColorName;

    $.each(newColors, function () {
      var swatch = $('<li/>', {
        class: 'color-item custom-cursor',
        'data-text': this.name,
        'data-shade': this.shade,
        'data-color': this.color,
      }).appendTo(swatchHolder);
      this.dark === false ? swatch.addClass('light') : swatch.addClass('dark');
      $(swatch).css('background-color', this.color);
      $(swatch).data('color', this.color);
      $(swatch).data('colorName', this.name);
      $(swatch).data('slug', this.slug);
      $(swatch).on('click', swatchClick);
      $(swatch).append('<span class="tooltip">' + this.name + '</span>');
      $(swatch).append('<span class="shade">' + this.shade + '</span>');
      var selected = $('<span/>', { class: 'selected' }).appendTo(swatch);
    });

    updateTooltipsPositions();

    var swatchPos = $('.colorHolder').position();
    var swatchHeight = $('.colorHolder').outerHeight(true) + swatchPos.top;
    closeOffset = swatchHeight - $('.swatchHolder').outerHeight();

    $('.swatchHolder').on('mouseenter mouseleave', swatchMove);
    $('.swatchHolder').css('bottom', closeOffset);
    swatchUp = { css: { bottom: 0 } };
    swatchDown = { css: { bottom: closeOffset } };
  };

  $.fn.makeSVGcolor = function (svgURL) {
    mainHolder = this;
    $(this).load(svgURL, function () {
      svgObject = $('svg', this);
      back = $('g#BackOfSuit').children().toArray();
      front = $('g#FrontOfSuit').children().toArray();
      allBackShapes = [];
      back.forEach(function (item) {
        if (item.childElementCount) {
          Array.prototype.forEach.call(item.children, function (childItem) {
            allBackShapes.push(childItem);
          });
        } else {
          allBackShapes.push(item);
        }
      });
      allFrontShapes = [];
      front.forEach(function (item) {
        if (item.childElementCount) {
          Array.prototype.forEach.call(item.children, function (childItem) {
            allBackShapes.push(childItem);
          });
        } else {
          allBackShapes.push(item);
        }
      });
      svgColor = allFrontShapes.concat(allBackShapes);
      $(svgColor).on('click', colorMe);
      $(colorsContainer).makeSwatches();
    });
  };

  $.fn.btnClear = function () {
    btnClear = this;
    $(btnClear).on('click', svgClear);
    colorCount = 0;
  };

  $.fn.btnOpenForm = function () {
    btnOpenForm = this;
    $(btnOpenForm).on('click', openForm);
  };

  $.fn.btnDownload = function (type) {
    if (type == 'PNG') {
      btnDownloadPNG = this;
      $(this).on('mouseenter', svgDownloadPNG);
    } else {
      btnDownloadSVG = this;
      $(this).on('mouseenter', svgDownloadSVG);
    }
  };

  $.fn.undoColoring = function () {
    btnUndo = this;
    $(btnUndo).on('click', undoColoring);
  };

  $(prevElement).on('click', prevColoring);
})(jQuery);

var queryString = window.location.search;
var urlParams = new URLSearchParams(queryString);
var suitVariant = urlParams.get('variant');

switch (suitVariant) {
  case 'rc':
    $('#ActivityDIV').makeSVGcolor(
      './assets/svg/suite-1.svg'
    );
    break;
  case 'rc-air':
    $('#ActivityDIV').makeSVGcolor(
      './assets/svg/suite-2.svg'
    );
    break;
  default:
    $('#ActivityDIV').makeSVGcolor(
      './assets/svg/suite-1.svg'
    );
    break;
}

$('#btnClear').btnClear();
$('#btnDownloadSVG').btnDownload();
$('#btnOpenForm').btnOpenForm();
$('#btnUnDo').undoColoring();
