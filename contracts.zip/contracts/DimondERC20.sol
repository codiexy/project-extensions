// SPDX-License-Identifier:MIT
pragma solidity ^0.8.10;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/Pausable.sol";

contract DiamondVerseToken is ERC20, Ownable, Pausable {
    uint8 private _decimals;
    uint256 public tokenPrice = 100; // Token price in cents
    address distributorAddress;
    uint256 public transInitialAmount;
    
    constructor(uint256 initialSupply, uint256 _transInitialAmount, uint8 _decimalVal) ERC20("DiamondVerse Token", "DVT") {
        require(_decimalVal <= 18, "Decimals must be 18 or lower");
        _mint(msg.sender, initialSupply * (10 ** uint256(_decimalVal)));
        transInitialAmount = _transInitialAmount * (10 ** uint256(_decimalVal));
        _decimals = _decimalVal;
    }

    function transferAmountMP(address _to, uint256 _amount)external onlyOwner{
        uint256 amount = _amount * (10 ** decimals());
        require(amount >= transInitialAmount,"amount is less then initial amount");
        transfer(_to, amount);
        // _transfer(owner(), _to, amount);
    }

    function setInitialAmount(uint256 _transInitialAmount)external onlyOwner{
        transInitialAmount = _transInitialAmount * (10 ** decimals());
    }
    
     function decimals() public view override returns (uint8) {
        return _decimals;
    }

    function setDecimals(uint8 decimals_) external onlyOwner{
        require(decimals_ <= 18, "Decimals must be 18 or lower");
        _decimals = decimals_;
    }

    function pause() public onlyOwner {
        _pause();
    }

    function unpause() public onlyOwner {
        _unpause();
    }

    function _beforeTokenTransfer(address from, address to, uint256 amount)
        internal
        whenNotPaused
        override
    {
        super._beforeTokenTransfer(from, to, amount);
    }
   
    function setTokenPrice(uint256 _centsPrice) external onlyOwner {
        tokenPrice = _centsPrice;
    }
    
    function burnTokens(uint256 amount) public onlyOwner {
        _burn(msg.sender, amount);
    }
}
